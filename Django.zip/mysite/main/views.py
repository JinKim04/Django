from django.shortcuts import render, redirect
from django.contrib import messages
from .forms import ContentForm
from .models import Content

# Create your views here.
def index(request):
    if request.method == "POST":
        form = ContentForm(request.POST)
        if form.is_valid():
            content_form = form.save(commit=False)
            content_form.save()
            return redirect('result/')
        else:
            messages.error(request, "error")
            return redirect('main/index.html')
        
    else:
        form = ContentForm()
        context = {
            'form' : form
        }
        return render(request, 'main/index.html', context)
    
def result(request):
    result_list = Content.objects.all()
    context = {
        'result_list' : result_list
    }
    return render(request, 'main/result.html', context)
    